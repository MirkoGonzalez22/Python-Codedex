import random

bday_messages = [
    '¡Espero que tengas un muy feliz cumpleaños! 🎈',
'Es tu día especial: ¡sal y celebra! 🎉',
'Naciste y el mundo mejoró: ¡todos ganan! 🥳',
'¡Diviértete mucho en tu día especial! 🎂',
'¡Otro año más dando vueltas alrededor del sol! 🌞'
]


random_message = random.choice(bday_messages)


print(random_message)
